public class GoShoppingApp {
    public static void main(String[] args) {
        // Create users
        User primeUser = new PrimeAccount("john_doe", "john@example.com");
        User normalUser = new NormalAccount("jane_doe", "jane@example.com");

        // Create products
        Product laptop = new Product(1, "Laptop", 1000);
        Product headphones = new Product(2, "Headphones", 150);

        // Add products to Prime user's cart
        primeUser.addToCart(laptop);
        primeUser.addToCart(headphones);

        // Checkout for Prime user
        ShoppingCart primeCart = primeUser.getCart();
        double primeTotalPrice = primeCart.getTotalPrice(primeUser);
        System.out.println("Prime user total price with discount: $" + primeTotalPrice);

        // Create order for Prime user
        Order primeOrder = new Order(primeUser, primeCart);
        primeOrder.processOrder();
        System.out.println(primeOrder);

        // Add products to Normal user's cart
        normalUser.addToCart(laptop);
        normalUser.addToCart(headphones);

        // Checkout for Normal user
        ShoppingCart normalCart = normalUser.getCart();
        double normalTotalPrice = normalCart.getTotalPrice(normalUser);
        System.out.println("Normal user total price: $" + normalTotalPrice);

        // Create order for Normal user
        Order normalOrder = new Order(normalUser, normalCart);
        normalOrder.processOrder();
        System.out.println(normalOrder);
    }
}
