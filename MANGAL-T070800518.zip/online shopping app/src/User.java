public abstract class User {
    protected String username;
    protected String email;
    protected ShoppingCart cart;

    public User(String username, String email) {
        this.username = username;
        this.email = email;
        this.cart = new ShoppingCart();
    }

    public void addToCart(Product product) {
        cart.addItem(product);
    }

    public ShoppingCart getCart() {
        return cart;
    }

    public abstract double applyDiscount(double price);
}
