import java.time.LocalDateTime;

public class Order {
    private User user;
    private ShoppingCart cart;
    private LocalDateTime orderDate;
    private String status;

    public Order(User user, ShoppingCart cart) {
        this.user = user;
        this.cart = cart;
        this.orderDate = LocalDateTime.now();
        this.status = "Processing";
    }

    public void processOrder() {
        // Simulate payment processing and confirmation
        this.status = "Completed";
    }

    public String trackOrder() {
        return status;
    }

    @Override
    public String toString() {
        return "Order{" +
                "user=" + user.username +
                ", cart=" + cart +
                ", orderDate=" + orderDate +
                ", status='" + status + '\'' +
                '}';
    }
}
