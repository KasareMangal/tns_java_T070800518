public class PrimeAccount extends User {
    public PrimeAccount(String username, String email) {
        super(username, email);
    }

    @Override
    public double applyDiscount(double price) {
        return price * 0.9; // 10% discount
    }
}
