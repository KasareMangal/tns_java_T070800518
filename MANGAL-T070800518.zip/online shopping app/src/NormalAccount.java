public class NormalAccount extends User {
    public NormalAccount(String username, String email) {
        super(username, email);
    }

    @Override
    public double applyDiscount(double price) {
        return price; // No discount
    }
}
